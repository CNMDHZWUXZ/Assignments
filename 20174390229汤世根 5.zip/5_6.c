#include<stdio.h>
#include<math.h>
main()
{
    int i=1;
    double pai,n=1;
    for(pai=0;n>=6e-6;i++)
    {
        n=1./(2*i-1);
        pai+=n*pow(-1,i+1);
    }
    pai=4*pai;
    printf("pai=%f",pai);
}
