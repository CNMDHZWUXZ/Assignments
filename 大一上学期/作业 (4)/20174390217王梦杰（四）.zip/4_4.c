#include<stdio.h>
main()
{
	int i,a;
	scanf("%d",&i);
	a=i;
	while(i!=0)
	{a=i%10;
	printf("%d",a);
	   i=i/10;}
}
