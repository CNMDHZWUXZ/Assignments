#include<stdio.h>
main()
{
    int year=1,num=0;
    while(year>=1&&year<2017)
    {
        year++;
        if(year%4==0&&year%100!=0)
            printf("%-15d\t",year);
        if(year%4==0&&year%100!=0)
        num++;

    }
    printf("num=%d\n",num);
}
