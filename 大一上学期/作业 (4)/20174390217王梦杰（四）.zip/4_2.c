#include<stdio.h>
main()
{
    int n,sum=0;
    for(n=1;n<1000;n+=2)
        sum+=n;
    printf("%d",sum);
}
