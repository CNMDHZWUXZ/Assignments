#include<stdio.h>
main()
{
    int n=1,num=0;
        while(n>=1&&n<=1000)
        {
            n++;
            if(n%3==0&&n%5!=0)
                printf("%d\t",n);
            if(n%3==0&&n%5!=0)
            num++;
        }
        printf("num=%d\t",num);
}
