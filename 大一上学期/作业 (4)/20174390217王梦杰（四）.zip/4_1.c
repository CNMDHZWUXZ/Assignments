#include<stdio.h>
main()
{
    int n=0;
    while(n>=0&&n<=1000)
    {
        n++;
        printf("%d\t",n);
    }
}
