#include<stdio.h>
main()
{
int x=1,count=0;
while(x<=1000)
{
  x++;
  if(x%3==0&&x%5!=0)
  {printf("%16d",x);
   count++;
  }
printf("%d",count);
}
}
