#include <stdio.h>
main()
{
	int year=0,count=0;
	while (year<=2017)
	{
		year++;
		if (year%4==0&&year%100!=0||year%400==0)
         {count+=1;
		printf("%16d",year);
		}
	}
	printf("%d\n",count);

}