#include<stdio.h>
main()
{
	int x,y;
	printf("wait a input:");
	scanf("%d",&x);
	y=x;
	if(x<0)
		printf("error");
	   if(x<10)
		   printf("%d",y);
	while(y>0)
	{	y%=10;
	    printf("%d",y);
		x/=10;
		y=x;
	}
}