#include<stdio.h>
main()
{
    int n;
    n=0;
    while(n<1000)
    {
        n++;
        printf("%d\t",n);
    }
}
