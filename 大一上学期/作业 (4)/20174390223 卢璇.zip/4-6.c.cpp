#include"stdio.h"
main()
{
    int n,count=0;
    for(n=1;n<=1000;n++);
    {
        if(n%3==0&&n%5!=0)
        {
            printf("%d\t",n);
            count++;
        }
    }
    printf("%d",count);
}
