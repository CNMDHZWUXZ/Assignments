#include<stdio.h>
main()
{
    int n,sum;
    n=1;
    sum=0;
    while(n<1000)
    {
        sum=sum+n;
        n=n+2;
    }
    printf("%d",sum);
}
