#include<stdio.h>
main()
{
    int n,count=0;
    for(n=1;n<=2017;n++)
    {
        if(n%4==0&&n%100!=0||n%400==0)
        {
            printf("%10d\t",n);
            count++;
        }
    }
    printf("%d",count);
}
