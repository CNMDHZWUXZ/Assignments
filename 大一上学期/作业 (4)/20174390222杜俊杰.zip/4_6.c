#include"stdio.h"
main()
{
    int m=1,n=0;
    while(m<=1000&&m>=1)
    {   m++;
        if(m%3==0&&m%5!=0)
        {   printf("\n%5d",m);
            n=n+1;
        }}
        printf("\n%5d",n);

}
