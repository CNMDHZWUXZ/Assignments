#include<stdio.h>
int main()
{
    int m,n,temp,i;
    scanf("%d%d",&m,&n);
    if(m>n)
    {
        temp=n;
        n=m;
        m=temp;
    }
    for(i=m;i>=1;i--)
    {
        if(m%i==0&&n%i==0)
        {
            printf("���Լ��Ϊ%d,��С������Ϊ%d\n",i,m*n/i);
            break;
        }
    }
    return 0;
}
