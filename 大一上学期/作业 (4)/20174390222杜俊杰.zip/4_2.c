#include"stdio.h"
main()
{
   int n=1,m=0;
   while(n<=1000)
    {m=m+n;
   n=n+2;}
   printf("m=%d",m);

}
