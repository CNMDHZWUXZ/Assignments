#include"stdio.h"
main()
{
    int n;
    for(n=1;n<=1000;n++)
        printf("%3d",n);

}
