#include"stdio.h"
main()
{
    int year=1,n=0;
    while(year<=2017)
    {
        if((year%4==0&&year%100!=0)||year%400==0)
        {  printf(" %d",year);
           n=n+1;}
        year=year+1;

        if(n%5==0)
        printf("\n");
    }
        printf("\n n=%d",n);

}
