#include"stdio.h"
main()
{
    int x;
    scanf("%d",&x);
    while(x>0)
    {
        printf("%3d",x%10);
        x=x/10;
    }
}
