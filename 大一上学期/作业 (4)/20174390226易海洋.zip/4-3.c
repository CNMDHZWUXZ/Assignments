#include <stdio.h>
main()
{
    int yy=1,count=0;
    for (yy;yy<=2017;yy++)
        {if(yy%4==0&&yy%100!=0||yy%400==0)
           {printf("%-20d",yy);
            count++;
           }
        }
    printf("%d\n",count);
}
