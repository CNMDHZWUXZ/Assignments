#include <stdio.h>
main()
{
    int i,count=0;
    for (i;i<=1000;i++)
        {if(i%3==0&&i%5!=0)
           {printf("%-5d",i);
            count++;
           }
        }
    printf("%d\n",count);
}

