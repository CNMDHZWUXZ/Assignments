#include <stdio.h>
main()
{
    int i;
    for(i=1;i<=1000;i++)
    {
        printf("%10d",i);
    }
}
