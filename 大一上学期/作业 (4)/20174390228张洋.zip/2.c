#include<stdio.h>
main()
{
    int sum=0,n=1;
    while(n<=1000)
    {
        sum=sum+n;
        n=n+2;
       }
     printf("sum=%d\n",sum);
}
