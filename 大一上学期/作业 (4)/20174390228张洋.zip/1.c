#include<stdio.h>
main()
{
    int n=1;
    while(n<=1000)
    {
        printf("%d ",n);
        n=n+1;
    }
}
