#include<stdio.h>
main()
{
    int year=1,count=0;
    while(year<=2017)
    {
        if (year%4==0&&year%100!=0||year%400==0)
            count+=1,
            printf("%d ",year);
        if (count%5==0)
            printf("\n");
        year+=1;
    }
    printf("count=%d",count);

}
