#include<stdio.h>
main()
{
    int n=1,count=0;
    while(n<=1000)
    {
        if(n%3==0&&n%5!=0)
           {
             printf("%d ",n);count+=1;
            if(count%5==0)
            printf("\n");}
        n++;

    }
    printf("count=%d",count);
}
