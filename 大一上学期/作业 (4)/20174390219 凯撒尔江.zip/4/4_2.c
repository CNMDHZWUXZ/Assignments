#include<stdio.h>
int main()
{
   int s=0,i;
   for(i=1;i<=1000;i+=2)
s+=i;
printf("%d\n",s);
}