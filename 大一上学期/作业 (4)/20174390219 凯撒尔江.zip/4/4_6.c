#include<stdio.h>
int main()
{
    int i,count=0;
    for (i=0;i<=1000;i++)
    {
        if(i%3==0&&i%5!=0)
        {
            printf("%20d\t",i);
            count++;
        }
    }
    printf("%d\n",count);

}
