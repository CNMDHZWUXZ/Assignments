#include<stdio.h>
int main()
{
int year,count=0;
for(year=1;year<2017;year++)
{
if((year%4==0&&year%100!=0)||(year%400==0))
printf(" %d",year);
  count++;
             if(count%20==0)
             printf("\n");
}
}