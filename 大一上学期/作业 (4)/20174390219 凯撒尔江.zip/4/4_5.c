#include<stdio.h>
main()
{
int m,n,x=2,max=0,min;
printf("����������:");
scanf("%d %d",&m,&n);
while(x<m&&x<m)
{if(m/x==0&&n/x==0)
   max=x;
            printf("max=%d\n",max);
    ++x;
}

}