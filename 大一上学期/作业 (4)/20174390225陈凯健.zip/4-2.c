#include"stdio.h"
main()
{
    int i=1,sum=0;
    while(i<1001)
    {
        if(i%2!=0)
            sum=sum+1;
        i++;
    }
    printf("%d",sum);
}
