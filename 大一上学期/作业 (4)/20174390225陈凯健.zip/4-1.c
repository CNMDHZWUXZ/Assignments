#include"stdio.h"
main()
{
    int i=1;
    do
    {
           i++;
    printf("%d\n",i);
    }

    while(i<1000);

}
