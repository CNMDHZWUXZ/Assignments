#include"stdio.h"
main()
{
    int i,sum=0,m;
    for(i=1;i<=1000;i++)
    {
       if((i%3==0)&&(i%5!=0))
          {
            sum++;
            printf("%d\n",i);
          }
    }
    printf("%d",sum);
}
