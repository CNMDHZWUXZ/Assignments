#include"stdio.h"
main()
{
    int count=0;
    int i,o,c=0;
    for(i=1;i<=2017;i++)
    {
       o=((i%4==0&&i%100!=0)||(i%400==0))?1:0;
       if(o)
          {c++;
          count++;
          printf("% d",i);
          if(count%5==0)
          printf("\n");
          }
    }

    printf("%d",c);
}
