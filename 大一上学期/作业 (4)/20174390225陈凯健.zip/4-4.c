#include"stdio.h"
main()
{
    int n,b;
    scanf("%d",&n);
    int d=0;
    while(n)
    {
        b=n%10;
        d=d*10+b;
        n=n/10;
    }
    printf("%d",d);
    return 0;

}
