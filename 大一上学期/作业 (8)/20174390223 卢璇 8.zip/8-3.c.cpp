#include<stdio.h>
#include<math.h>
int fun(int n)
{
    int k,i;
    k=sqrt(n);
    for(i=2;i<=k;i++)
        if(n%i==0) break;
    if(i>=k+1) return 1;
    else return 0;
}
main()
{
	int i,count=0,m,max=100;
	for(i=9999;i>=100;i--)
	{
		m=i;
		while(m>1)
			if(fun(m))m=m/10;
			else break;
			if(m<=0)
			{
				if(max<i)
					max=i;
				count++;
				printf("%5d\n",i);
			}
}
	printf("����%5d,���%5d\n",count,max);
}
