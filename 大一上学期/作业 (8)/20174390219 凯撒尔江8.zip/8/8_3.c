#include<stdio.h>
int sushu(int a)
{
	int b;
	if(a>1)
    {
        for(b=2;b<a;b++)
        if(a%b==0)
            return 0;
        return 1;
    }
    return 0;
}
int(chaojisushu(int a))
{
    for(;a!=0;a/=10)
    {
        if(!sushu(a))
            return 0;
    }
    return 1;
}
main()
{
    int x,count=0,max;
    for(x=100;x<=9999;x++)
    {
        if(chaojisushu(x))
            {printf("%20d\t",x);
            count++;
            max=x;
            }
    }
    printf("\n����Ϊ��%d\n��󳬼�����Ϊ��%d",count,max);
}
