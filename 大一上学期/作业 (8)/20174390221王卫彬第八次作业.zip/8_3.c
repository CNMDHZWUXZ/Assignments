#include<stdio.h>
int supprime(int n)
{
    int i;
    for(i=2;i*i<=n;i++)
        if(n%i==0)
          break;
    if(i*i>n&&n>1)
        return 0;
    return 1;
}
main()
{
    int n,k,sum=0,count=0,max;
    for(n=100;n<=9999;n++)
    {
        k=n;
        while(k)
{
            sum+=supprime(k);
            k/=10;
            /printf("%d,%d\n",sum,k);
        }
        if(sum==0)
        {
            count++;
            max=n;
            printf("%4d\n",n);
        }
        sum=0;
    }
    printf("count:%d,max:%d",count,max);
}
