#include<stdio.h>
int fun(int n)
{  int i;
   for(i=2;i<=n-1;i++)
   {
       if(n%i==0)
       return 0;
   }
   if(n==1)
   {
       return 0;
   }
   return 1;
}
int chu(int n)
{
    while(n)
    {
        n=n/10;
        if(!fun(n))
        {
            return 0;
        }
    }
    return 1;
}
main()
{
    int i,count=0,t;
    for(i=100;i<=9999;i++)
    {
        if(fun(i))
        {
            if(chu(i))
            {
                t=i;
                count++;
                printf("%d\n",i);
            }
        }
    }
    printf("%d  %d",t,count);
}
