#include<stdio.h>
/*********found******/
int fun(int s)
{
    int t,s1=10;
    t=s%10;
    while(s>0)
    {
        s=s/100;
        t=s%10*s1+t;
        /******found****/
        s1=s1*10;
    }
    /******found****/
       return t;
}
main()
{
    int s,t;
    printf("\nplease enter s:");
    scanf("%d",&s);
    t=fun(s);
    printf("the result is: %d\n",t);
}
