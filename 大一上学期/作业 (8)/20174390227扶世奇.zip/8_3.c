#include<stdio.h>
int fun(int x)
{
    int y;
    for(y=2;y<=x;y++)
    {
      if (x%y==0&&y<x)
        return 0;
       else if(x==y)
       {
        return 1;
       }
    }
}
main()
{
    int n,m,sum=0,max;
    for(n=100;n<=9999;n++)
    {
     if(fun(n))
     {
         m=n;
         while(m)
         {
             m=m/10;
             if (m==0)
         {
            max=n;
            printf("%d ",n);
            sum++;
         }
         if(fun(m)&&m!=1)
             continue;
         else
             break;
     }
     }
    }
    printf("\n���ĳ�������Ϊ%d\n",max);
    printf("����%d����������",sum);

}
