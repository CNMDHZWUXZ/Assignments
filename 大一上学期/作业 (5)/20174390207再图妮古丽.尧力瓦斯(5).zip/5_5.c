#include<stdio.h>
main()
{
    int x,i,sum,count=0,max;
    for(x=2;x<=1000;x++)
    {
        for(i=1,sum=0;i<=x/2;i++)
        {
            if(x%i==0)
            {
               sum+=i;
            }
        }
        if(sum==x)
        {
            printf("%d\t",x);
            count++;
            max=x;
        }
    }
    printf("\nmax=%d count=%d\n",max,count);
}
