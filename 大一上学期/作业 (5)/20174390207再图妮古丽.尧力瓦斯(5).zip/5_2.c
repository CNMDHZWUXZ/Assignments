#include<stdio.h>
main()
{
    int x,i,count=0;
    for(x=2;x<10000;x++)
    {
        for(i=2;i<x;i++)
        {
            if(x%i==0)
            break;
        }
        if(i==x)
        {
            count++;
            printf("%d\t",x);
        }

    }
    printf("\ncount=%d\n",count);
}
