#include<stdio.h>
#include<math.h>
main()
{
    int n;
    double x=1,sum=0;
    for(n=1;n<pow(10,6);n++)
    {
        x=(double)pow(-1,n+1)*(1.0/(double)(2*n-1));
        sum+=x;
    }
    printf("sum=%f",sum);
}
