#include<stdio.h>
main()
{
    int x,sum,count;
    for(x=1000;x<=9999;x++)
    {
        if(x%4==0&&x%10==6)
        {
            sum+=x;
            count++;
        }
    }
    printf("sum=%d count=%d\n",sum,count);
}
