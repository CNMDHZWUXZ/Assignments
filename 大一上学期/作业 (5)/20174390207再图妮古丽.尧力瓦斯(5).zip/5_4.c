#include<stdio.h>
main()
{
    int hong,bai=1,hei;
    for(;bai<=5;bai++)
    {
        for(hong=0;hong<=3;hong++)
        {
            for(hei=0;hei<=5;hei++)
            {
                if(bai+hong+hei==6)
                {
                    printf("����=%d,����=%d,����=%d\n",bai,hong,hei);
                }
            }
        }
    }
}
