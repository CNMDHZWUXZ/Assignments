#include<stdio.h>
main()
{ int n,i,m,count=0,max=0;
 for(n=1;n<=1000;n++)
 {
     m=0;
	for(i=1;i<=n/2;i++)
    if(n%i==0)
        m=m+i;
	 if(m==n)
	 {
	     count++;
	     printf("%d\n",n);
	     max=m;
     }
 }
  printf("��Ŀ=%d,���=%d",count,max);
}
