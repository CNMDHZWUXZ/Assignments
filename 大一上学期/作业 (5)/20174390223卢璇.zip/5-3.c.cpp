#include <stdio.h>
int main()
{
    int sum=0,i,count;
    for(i=1000;i<10000;i++)
        {
            if(i%10==6&&i%3==0)
            sum+=i;
        }
        count++;
        printf("%d,%d",sum,count);
 }
