#include<stdio.h>
main()
{
    int n;
    double sum=0;
    for(n=1;;n=n+2)
    { if(n%2==0)
         sum=sum-1.0/(2*n-1);
      else
         sum=sum+1.0/(2*n-1);
      if(1.0/(2*i-1)<10e-6) break;
	 }
	 printf("%f",sum);
}
