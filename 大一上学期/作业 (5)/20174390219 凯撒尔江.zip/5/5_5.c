#include <stdio.h>
int main()
{
int r,j,i;
for(i=2;i<=1000;i++)
{
r = 0;
for(j=1;j<i;j++)
  {
if(i%j==0)
    {
      r=r+j;
    }
  }
if(r==i)
          {
          printf("resualt:%d\n",r);
          }
}
}