#include <stdio.h>
#include <math.h>
int main()
{
    double sum=1,a=3,b=1,k;
    do
    {
        k=a/b;
        sum=sum+k;
        a=-a;
        b=+2;
    }
    while (fabs(k)>1.0e-6);
        printf("sum is %if",4*sum);
}