#include <stdio.h>
main()
{
int a,b,c,d,e,i,count=0;
for(i=1;i<=10000;i++)
{
a=i/10000;
b=i/1000%10;
c=i/100%10;
d=i/10%10;
e=i%10;
if(a*a*a+b*b*b+c*c*c+d*d*d+e*e*e==i)
{
    printf("%20d",i);
    count++;
}
}
printf("%d\n",count);
}