#include<stdio.h>
main()
{
    int i,count=0;
for(i=1000;i<=9999;i++)
   {
   if(i%4==0)
   if(i%10==6)
   printf("%20d",i);
   count++;
   }
   printf("%d\n",count);
}