#include<stdio.h>
main()
{
int a,b,i=0,n;
for(a=2;a<=1000;i++)
{
  n=0;
  for(b=1;b<a;b++)
 if(a%b==0)
  n=n+b;
 if(n==a)
 {
 printf("%d  ",a);
  i++;
  if(i%8==0)
  printf("\n");
 }
   return 0;
}      
}