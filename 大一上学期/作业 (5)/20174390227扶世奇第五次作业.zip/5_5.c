#include<stdio.h>
main()
{
    int n,i,j,n=1000,num=0,max;
    for(n=1000;n>1;n--)
    {
        i=0;
        for(j=1;j<n;j++)
            if(n%j==0)
              i+=j;
              if(i==n)
                    max=i;
    }
    printf("共有%d个完数，最大的是%d",num,max);
}
