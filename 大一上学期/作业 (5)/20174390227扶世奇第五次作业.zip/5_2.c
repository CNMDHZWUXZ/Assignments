#include<stdio.h>
main()
{
   int n,i,count=1;
   for(n=2;n<=10000;n++)
   {
       for (i=2;i<=n-1&&n%i!=0;i++)
      {    if(i==n-1)
        {
        count++;
        printf("%d\n",n);
        }
      }
   }
   printf("%d",count);
}

