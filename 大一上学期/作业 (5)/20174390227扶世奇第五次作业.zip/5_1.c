#include <stdio.h>
main()
{
  int i,a,b,c,d,n,count=0;
  for(i=100;i<1000;i++)
  {a=i%10;
  b=i%100/10;
  c=i/100;
  n=a*a*a+b*b*b+c*c*c;
  if(a*a*a+b*b*b+c*c*c==i)
  {
  printf("%d\n",i);
  count++;}
  }
  for(i=1000;i<10000;i++)
  {a=i%10;
  b=i%100/10;
  c=i%1000/100;
  d=i/1000;
  n=a*a*a*a+b*b*b*b+c*c*c*c+d*d*d*d;
  if(n==i)
    {printf("%d\n",i);
  count++;}
  }
  printf("\n%d",count);
}
