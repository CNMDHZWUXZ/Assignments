#include <stdio.h>
main()
{
	char c;
	int letter=0,number=0,blank=0;
	printf("请输入一行字符",c);
        scanf("%c,&c);
		if (c >= 'a'&&c <= 'z' || c >= 'A'&&c <= 'Z')
			letter++;
		else if (c == ' ')
                    blank++;
		    else
		            number++;
	printf("字母数%d\n空格数%d\n数字数%d\n",letter,blank,number);
}
