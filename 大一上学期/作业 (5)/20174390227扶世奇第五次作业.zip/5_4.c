#include <stdio.h>
mian()
{
   int a,b,c;
   for(a=0;a<=3;a++)
   for(b=1;b<=5;b++)
   for(c=0;c<=6;c++)
   if(a+b+c==6)
   printf("红球个数%d白球个数%d黑球个数%d\n",a,b,c);
}
