#include<stdio.h>
main()
{
    float sum=0,i,a,b;
    for(i=1;(1/n)>(1e-6);i+=2)
    {
        if(i%2==0)
           a+=(1/i);
        else b+=(-1)*(1/i);
       sum=a+b;
    }
    printf("%f",sum);
}
