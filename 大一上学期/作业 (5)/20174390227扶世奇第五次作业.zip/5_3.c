#include<stdio.h>
main()
{
    int n,sum=0,count=0;
    for(n=1000;n<10000;n++)
    {
        if(n%4==0&&n%10==6)
            cuont++;
            sum+=n;
    }
    printf("%d\n%d\n",count,sum);
}
