#include"stdio.h"
main()
{
    int i,count=0,sum=0;
    for(i=1000;i<10000;i++)
    {
        if(i%4==0&&i%10==6)
        {
            count++;
            sum=sum+i;
        }

    }
        printf("%d %d ",sum,count);

}
