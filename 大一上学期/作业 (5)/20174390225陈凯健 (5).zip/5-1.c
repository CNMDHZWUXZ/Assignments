#include"stdio.h"
main()
{
    int a,b,c,d,n,count=0,s=0;
    for(n=100;n<10000;n++)
    { if(n<1000)
    {
         a=n/100;
       b=n/10-a*10;
       c=n%10;
        if(n==a*a*a+b*b*b+c*c*c)
        { printf("%d\n",n);
          count++;
         }
        }
        if(n>=1000)
        {
            a=n/1000;
          b=n/100-a*10;
          c=n/10-a*100-b*10;
          d=n%10;
       if(n==a*a*a*a+b*b*b*b+c*c*c*c+d*d*d*d)
         {printf("%d\n",n);
          s++;

         }
        }

    }
    printf("����=%d",count+s);
}
