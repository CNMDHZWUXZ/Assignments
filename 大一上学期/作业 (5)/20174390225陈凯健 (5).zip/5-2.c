#include"stdio.h"
main()
{
    int i,j,count=0;
    for(i=2;i<1000;i++)
    {
    for(j=2;j<i;j++)
        if(i%j==0)break;
     if(i==j)
    {
     printf("%d\n",i);
     count++;
    }
    }
    printf("count=%d",count);
}
