#include<stdio.h>
main()
{
    int n;
    double s=0.0;
    for(n=1;1.0/(2*n-1)>1e-6;n++)
        { if(n%2!=0)
         s=s+1.0/(2*n-1);
          else
            s=s-1.0/(2*n-1);
         }
    printf("s=%f",4*s);

}
