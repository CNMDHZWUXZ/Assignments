#include<stdio.h>
main()
{
	int r,w,b;
	for(w=1;w<=5;w++)
	{
		for(b=0;b<=6;b++)
		{
			r=6-w-b;
			if(r>=0&&r<=3)
				printf("%d个红球%d个白球%d个黑球\n",r,w,b);
		}
	}
}
