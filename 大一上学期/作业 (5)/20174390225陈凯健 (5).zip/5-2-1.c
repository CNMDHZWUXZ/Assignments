#include"stdio.h"
main()
{
    int m,i,count=0;
    for(m=2;m<10000;m++)
    {
        i=2;
        while(m%i!=0&&i<=(m-1))
            i++;
        if(i==m)
        {
            printf("%  d",i);
            count++;
        }

    }
    printf("count=%d\n",count);
}
