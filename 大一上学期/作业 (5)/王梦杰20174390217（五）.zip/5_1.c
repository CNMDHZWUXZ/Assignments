#include<stdio.h>
main()
{
	int n,a,b,c,d,count=0;
	for(n=100;n<10000;n++)
	{
		a=n%10;
		b=n/10%10;
		c=n/100%10;
		d=n/1000;
		if(d==0)
		{
			if(a*a*a+b*b*b+c*c*c==n)
			{
				count++;
		 	printf("%d\n",n);
			}
		}
		else
			if(a*a*a*a+b*b*b*b+c*c*c*c+d*d*d*d==n)
			{	count++;
			printf("%d\n",n);
		}
	}
   if(1*1*1*1*1+0*0*0*0*0+0*0*0*0*0+0*0*0*0*0+0*0*0*0*0+0*0*0*0*0==10000)
		 printf("10000");
 printf("\nˮ�ɻ�������%d��",count);
}
