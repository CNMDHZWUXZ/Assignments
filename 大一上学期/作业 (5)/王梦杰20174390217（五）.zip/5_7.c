#include<stdio.h>
main()
{
	int a,b,c,ch;
	a=b=c=0;
	while((ch=getchar())!='\n')
	{
		if ((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z'))
		b++;
		else if(ch>='0'&&ch<='9')
		a++;
		else if(ch==' ')
		c++;
	 }
	 printf("%d%d%d\n",b,a,c);
}
