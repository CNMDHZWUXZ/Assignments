#include<stdio.h>
main()
{
	int a,b,c;
	for(a=0;a<=3;a++)
		for(b=0;b<=5;b++)
		{
			c=6-a-b;
			if(c>0)
				printf("ºì%d°×%dºÚ%d\n",a,b,c);
		}

}
