#include<stdio.h>
main()
{
	double pi=0,sum=0,n=1;
    int i=1;
    do{
        sum=sum+i/n;
        n=n+2;
        i=-i;
    }
    while(1/n>0.0001);
    printf("PI��ֵ��:%f\n",4*sum);
}
