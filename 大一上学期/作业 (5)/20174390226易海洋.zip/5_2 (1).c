#include<stdio.h>
int main()
{
    int i,j,count=0;
    for(i=2;i<=10000;i++)
    {
        for(j=2;j<i;j++)
        {
            if(i%j==0){
				break;
            }
        }
        if (i==j){
        	count++;
			printf("%5d",i);
        }
    }
    printf("\n%d",count);
}
