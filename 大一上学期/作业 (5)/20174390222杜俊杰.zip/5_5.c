#include<stdio.h>
main()
{
    int y,x,sum=0,count=0,max;
    for(y=2;y<=1000;y++)
    {
        for(x=1;x<y;x++)
            if(x%y==0)
        {
            sum=sum+x;
        }
        if(sum==x)
        {
            count++;
            printf("%d\n",sum);
            max=sum;
        }
        sum=0;
    }
    printf("%d max:%d",count,max);
}
