#include<stdio.h>
main()
{
    int y,sum=0,count=0;
    for(y=1000;y<9999;y++)
        if(y%4==0&&y%10==6)
    {
        sum++;
        count=count+y;
        }
        printf("%d\n",sum);
        printf("%d\n",count);
}
