#include<stdio.h>
main()
{
    int m,n,sum=0;
    for(m=2;m<10000;m++)
    {
        n=2;
        while(m%n!=0&&n<=m-1)
          n++;
        if(n==m)
        {
            sum++;
            printf("%5d",m);
        }
    }
    printf("%5d",sum);
}
