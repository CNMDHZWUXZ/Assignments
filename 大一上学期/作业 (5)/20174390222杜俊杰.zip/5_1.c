#include<stdio.h>
main()
{
    int unit,ten,hundred,thousand,n,m=0;
    for(n=1;n<10000;n++)
    { thousand=n/1000;
      hundred=n/100-thousand*10;
      ten=n/10-thousand*100-hundred*10;
      unit=n-thousand*1000-hundred*100-ten*10;
      if(n>1000&&n==thousand*thousand*thousand*thousand+hundred*hundred*hundred*hundred+ten*ten*ten*ten+unit*unit*unit*unit)
       printf("%9d",n);
      if(n>100&&n<1000&&n==hundred*hundred*hundred+ten*ten*ten+unit*unit*unit)
       printf("%9d",n);
      else if(n<100&&n==ten*ten+unit*unit)
       printf("%9d",n);
       m++;
    }
    printf("%d",m);
}
