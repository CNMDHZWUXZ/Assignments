#include<stdio.h>
double fun(int k)
{
	double m,n,s=1.0,i;
	for(i=2;i<=2*k;i+=2)
	{
		m=i*i;
		n=(i-1)*(i+1);
		s=s*(m/n);
	}
	return s;
}
main()
{
	int k=10;
	printf("%f",fun(k));
}