#include<stdio.h>
int fun(int n)
{
	int i;
	if(n==1)
		i=1;
	else
		i=fun(n-1)*n;
	return i;
}
main()
{
	int n,sum=0;
	for(n=1;n<=10;n++)
	sum=sum+fun(n);
	printf("%d",sum);
}