#include<stdio.h>
double fun(double x,int n)
{
	int i,t=1,m=1;
	double s=1.0,a=1.0;
	for(i=1;i<=2*n;i++)
	{
		a*=x;
		t*=i;
		if(i%2==0)
		{
			m=-m;
			s=s+m*a/t;
		}
	}
	return s;
}
main()
{
	double x=5.6;
	int n=7;
	double a,b,c,s;
	a=fun(x,n);
	b=fun(x+2.3,n);
	c=fun(x-3.2,n+3);
	s=a/(b+c);
	printf("y=%f",s);
}