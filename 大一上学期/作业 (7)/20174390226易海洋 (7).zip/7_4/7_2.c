#include<stdio.h>
int fun(int m)
{
	int sum,i,k,n;
    for(i=1;i<=765;i++)
	{
		sum=i;
		n=i;
		for(k=1;k<m;k++)
		{
			n*=2;
			sum+=n;
		}
		if(sum==765)
			break;
		
	}
	return i;
}
main()
{
	int i,n;
	n=fun(8);
	for(i=1;i<8;i++)
		n=n*2;
	printf("%d",n);
}
