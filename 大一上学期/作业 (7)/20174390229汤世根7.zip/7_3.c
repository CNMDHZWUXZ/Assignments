#include<stdio.h>
#include<math.h>
float f(float x,int n)
{
    float s,k,i;
    for(s=0;n>=0;n--)
    {
        k=2*n;
        for(i=k-1;i>0;i--)
            k*=i;
        if(k==0)
            k=1;
        s+=pow(-1,n)*pow(x,2*n)/k;
    }
    return s;
}
main()
{
    float y,x;
    int n;
    scanf("%f%d",&x,&n);
    y=f(x,n)/(f(x+2.3,n)+f(x-3.2,n+3));
    printf("y=%f",y);
}
