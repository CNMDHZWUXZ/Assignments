#include<stdio.h>
#include<math.h>
main()
{
	int s,n,c;
	for(n=1;s!=765;n++)
	{
	    for(s=0,c=0;c<=7;c++)
        {
            s+=n*pow(2,c);
        }
	}
	n=(n-1)*pow(2,7);
	printf("塔顶灯数为%d",n);
}
