#include<stdio.h>
float f(float k)
{
    float n,s;
    for(s=1;k>=1;k--)
    {
        n=2*k;
        s*=n*n/(n-1)/(n+1);
    }
    return s;
}
main()
{
    float s,k;
    scanf("%f",&k);
    s=f(k);
    printf("s=%f",s);
}
