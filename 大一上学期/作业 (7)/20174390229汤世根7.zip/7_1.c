#include<stdio.h>
int fun(int n)
{
	int f;
	if(n==1||n==0)
		return 1;
	f=n*fun(n-1);
	return f;
}
main()
{
    int n,s=0;
	for(n=10;n>0;n--)
        s+=fun(n);
    printf("%d",s);
}
