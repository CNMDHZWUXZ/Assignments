#include<stdio.h>
float fun(float k)
{
    float s=1;
    if(k==1)
        return 4.0/3;
    else s*=(4*k*k/((2*k-1)*(2*k+1)))*fun(k-1);
    return s;
}
main()
{
    float x=10;
    printf("%f\n",fun(x));
}
