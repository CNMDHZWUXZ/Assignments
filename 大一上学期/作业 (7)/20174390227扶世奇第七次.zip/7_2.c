#include<stdio.h>
int fun(int x)
{
    int t,sum=0;
    for(t=1;t<=8;t++)
    {
       {
        sum=sum+x;
        x=x/2;
       }
    }return sum;
}
main()
{
    int x;
    for(x=0;x<=765;x=x+2)
        if(fun(x)==765)
        printf("�����ĵ���Ϊ%d",x);
}

