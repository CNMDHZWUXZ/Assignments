#include<stdio.h>
int f(int x)
{
    int t;
    if(x==0)
    {
        t=1;
        return t;
    }
    else
        t=f(x-1)*x;
      return t;
}
main()
{
    int n=5,s;
    s=f(n);
    printf("%d",s);
}
