#include<stdio.h>
double fun(double x,int n)
{
    int i,j=1,k=1;
    double s=1.0,y=1.0;
    for(i=1;i<=2*n;i++)
    {
        y=y*x;
        j=j*i;
        if(i%2==0)
        {
            k=-k;
            s=s+k*y/j;
        }return s;
    }
}
main()
{
    double x=5.6,y;
    int n=7;
    y=fun(x,n)/(fun(x+2.3,n)+fun(x-2.3,n+3));
    printf("%1f\n",y);
}
