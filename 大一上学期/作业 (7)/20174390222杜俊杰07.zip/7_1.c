#include<stdio.h>
int fun(int n)
{
	int f;
	if(n==1)
		f=1;
	else
		f=n*fun(n-1);
	return f;
}
main()
{
	int a,sum=0;
	for(a=1;a<10;a++)
		sum+=fun(a);
	printf("\n%d\n",sum);
}
