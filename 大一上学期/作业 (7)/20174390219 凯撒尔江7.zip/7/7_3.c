#include<stdio.h>
#include<math.h>
float sum(float x,int n)
{
    int sign=1,k;
	float s=1,j;
           if(n>=0)
			{
            sign=pow(-1,n);
			j=pow(x,2*n);
			k=jiecheng(2*n);
			s=s+sum(x,n-1);
			}
		return s;
}
int jiecheng(int n)
{
    int m;
	if(n==0||n==1)
		return 1;
	m=n*jiecheng(n-1);
	return m;
}
main()
{
	float y,y1,y2,x;
	int n;
	printf("Enter a number as X\n ");
	scanf("%f",&x);
		printf("Enter a number as n\n");
		scanf("%d",&n);
	y1=sum(x,n);
	y2=sum(x+2.3,n)+sum(x-3.2,n+3);
	y=y1/y2;
	printf("result\n%f",y);
}
