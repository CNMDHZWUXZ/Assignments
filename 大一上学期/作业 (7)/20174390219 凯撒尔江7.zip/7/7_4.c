#include<stdio.h>
float hanshu(int a)
{
    int i,x,y;
    float s=1;
    for(i=1;i<=a;i++)
       {
        x=(2*i)*(2*i);
        y=(2*i-1)*(2*i+1);
        s=s*x/y;
        }
    return s;

}
main()
{
    int k;
    printf("����������!\n");
    scanf("%d",&k);
    printf("%f",hanshu(k));
}
