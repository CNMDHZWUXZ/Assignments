#include<stdio.h>
int html(int p)
{
    int num,sum=0,k;
    num=p;
    for(k=1;k<9;k++)
      {
          sum+=num;
          num/=2;
      }
      return sum;

}
main()
{
    int p,sum;
    for(p=1;;p++)
    {
        sum=html(p);
        if(sum>=765)
            break;
    }
    printf("���ֵĵײ���\n%d",p);
}

