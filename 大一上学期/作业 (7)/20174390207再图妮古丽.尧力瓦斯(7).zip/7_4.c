#include<stdio.h>
#include<math.h>
double fun(int x)
{
    double f;
    f=pow(2*x,2)/(double)((2*x-1)*(2*x+1));
    return f;
}
main()
{
    int k;
    double S=1;
    printf("wait a input:");
    scanf("%d",&k);
    for(;k>0;k--)
        {
            S=S*fun(k);
        }
    printf("S=%f\n",S);
}
