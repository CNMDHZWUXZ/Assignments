#include<stdio.h>
int fact(int n)
{
    int f;
    if(n==1)
        return 1;
    f=n*fact(n-1);
    return f;
}
main()
{
    int a=10,f;
    for(;a>=1;a--)
     f=f+fact(a);
    printf("factorial=%d",f);
}
