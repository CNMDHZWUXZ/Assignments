#include<stdio.h>
#include<math.h>
int sum(int n)
{
    int s=0,a=0;
    for(;a<8;a++)
        s+=n*pow(2,a);
    return s;
}
int prime(int n)
{
    int x=1/*xΪ��������*/,y=1;
    for(;y!=n;x++)
        y=sum(x);
    return x-1;
}
main()
{
    int n=765,f;
    f=prime(n)*pow(2,7);
    printf("finally=%d",f);
}
