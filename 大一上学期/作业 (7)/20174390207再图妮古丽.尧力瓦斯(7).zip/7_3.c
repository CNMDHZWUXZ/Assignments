#include<stdio.h>
#include<math.h>
int fact(int n)
{
    int f;
    if(n==0)
        return 1;
    if(n==1)
        return 1;
    f=n*fact(n-1);
    return f;
}
double f(double x,int n)
{
    double s=0;
    for(;n>=0;n--)
        s+=pow(-1,n)*pow(x,2*n)/fact(2*n);
    return s;
}
main()
{
    double x,y,n;
    x=5.6;
    n=7;
    y=f(x,n)/(f(x+2.3,n)+f(x-3.2,n+3));
    printf("y=%f\n",y);
}
