#include<stdio.h>
float fun(float x,int n)
{
	int i,m=1,t=1;
	float s=1.0,w=1.0;
	for(i=1;i<=2*n;i++)
	{
		w=w*x;
		t=t*i;
		if(i%2==0)
		{
			m=-m;
			s=s+m*w/t;
		}
	}
	return s;
}
main()
{
	float x=5.6,y,a,b,c;
	int n=7;
	a=fun(x,n);
	b=fun(x+2.3,n);
	c=fun(x-3.2,n+3);
	y=a/(b+c);
	printf("%f",y);
}
