#include<stdio.h>
double fun(int k)
{
	int n;
	double s,a,b,c;
	n=1;
	s=1.0;
	while(n<=k)
	{
		a=2.0*n;
		b=a-1.0;
		c=a+1.0;
		s=s*a*a/b/c;
		n++;
	}
	return s;
}
main()
{
	int k=10;
	printf("%f",fun(k));
}
