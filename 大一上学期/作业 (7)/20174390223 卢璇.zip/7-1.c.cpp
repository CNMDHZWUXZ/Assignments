#include<stdio.h>
int fun(int n)
{
    if(n==1)
        return 1;
    else
        return n*fun(n-1);
}
main()
{
    int sum=0,i;
    for(i=1;i<=10;i++)
        sum+=fun(i);
    printf("%d\n",sum);
    return 0;
}
