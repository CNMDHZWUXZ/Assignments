#include<stdio.h>
double fun (int k)
{int n; float s,W,p,q;
n= 1;
s=1.0;
while(n<=k)
{w=2.0*n;
p=W-1.0;
q= w+1.0;
S= s*w*w/p/q;
n++;
return S
main()
{clrscr ();
printf ("%f" fun (10));
}
