#include<stdio.h>
int fun(int n)
{
int sum=0,j,t;
t=n;
for(j=1;j<=8;j++)
{sum=sum+t;

t=t*2;}
return sum;
}
main()
{
int i,n;
for(i=1;i<765;i++)
{
n=fun(i);
if(n>=765) break;
}
if(n==765) printf("�ײ�ĵ���Ϊ%d",i);
else printf("error");
}
