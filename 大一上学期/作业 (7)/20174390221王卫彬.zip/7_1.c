#include<stdio.h>
main()
{
    int i,sum=0;
    {
        for(i=0;i<=10;i++)
            sum+=fun(i);
    }
    printf("%d",sum);
}
int fun(int n)
{
    int t;
    if(n==1)
         t=1;
    else
        t=n*fun(n-1);
        return t;
}
