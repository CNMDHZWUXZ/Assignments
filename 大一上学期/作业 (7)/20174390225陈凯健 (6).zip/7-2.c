#include<stdio.h>
#include<math.h>
int jiec(int n)
{
    int i,sum=1;
    for(i=1;i<=n;i++)
      sum=sum*i;
    return sum;
}
float hanshu(float x,int n)
{
    int i,cou=0;
    for(i=1;i<=n;i++)
    {
        if(i%2!=0)
            cou=cou+pow(x,i)/jiec(i);
        else
            cou=cou-pow(x,i)/jiec(i);
    }
    return cou;
}
float jisuan(float x,int n)
{
    float he;
    he=hanshu(x,n)/(hanshu(x+2.3,n)+hanshu(x-3.2,n+3));
    return he;
}
main()
{
    int n;float x,jieguo;
    scanf("%f%d",&x,&n);
    jieguo=jisuan(x,n);
    printf("%f",jieguo);

}


