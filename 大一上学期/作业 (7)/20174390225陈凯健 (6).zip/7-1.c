#include<stdio.h>
int jiecheng(int x)
{
    int c;
    if (x==1) c=1;
    else c=x*jiecheng(x-1);
    return c;
}
main()
{
    int i,sum=0;
    for(i=1;i<=10;i++)
        sum=sum+jiecheng(i);
    printf("%d",sum);

}
