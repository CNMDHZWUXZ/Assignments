#include<stdio.h>
int chu(int z)
{int s;
    s=(z/255)*128;
    return s;
}
main()
{
    int i;
    scanf("%d",&i);
    printf("%d",chu(i));
}
