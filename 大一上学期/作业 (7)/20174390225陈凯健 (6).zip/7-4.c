#include<stdio.h>
#include<math.h>
float yunsuan(int x)
{
    float s;
    s=pow(2*x,2)/((2*x-1)*(2*x+1));
}
main()
{
    int k,i;
    float count=1.0;
    scanf("%d",&k);
    for(i=1;i<=k;i++)
    {
        count=count*yunsuan(i);
    }
        printf("%f",count);
}
