#include<stdio.h>
main()
{
int n;
scanf("%d",&n);
if(n%60==0)
printf("yes\n");
else
printf("NO\n");
}
