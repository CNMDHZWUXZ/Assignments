#include <stdio.h>
main()
{
    float tr,ma,rm,receive;
    printf("money:");
    scanf("%f",ma);
       switch((int)ma/1000)
{   case 0:tr=0;break;
    case 1:tr=0.05;break;
    case 2:case 3:tr=0.08 ;break;
    dafault:tr=0.1;break;


}
rm=ma*tr;
receive=ma-rm;
printf("税率：%f\n应交：%f\n应得：%f"，tr,rm,receive)



}
