#include<stdio.h>
main()
{
    int x,y;
    scanf("%d",&x);
    switch(x/10)
    {
        case 0:y=x;break;
        case 1:y=x*2+3;break;
        case 2:
        case 3:y=-0.5*x+10;
        default:printf("error");
    }
    printf("y=%d\n",y);
}
