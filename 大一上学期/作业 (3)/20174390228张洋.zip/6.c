#include<stdio.h>
main()
{
    int x;
    scanf("%d",&x);
    if (x%3==0&&x%4==0&&x%5==0)
        printf("Yes");
    else
        printf("No");
}
