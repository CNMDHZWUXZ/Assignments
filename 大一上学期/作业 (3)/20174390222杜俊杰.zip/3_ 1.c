#include<stdio.h>
main()
{
    int a;
    double x, y;
    scanf("%lf",&x);
    a=(int)(x/10);
    switch(a)
   {
       case 0:printf("%lf",y=x);break;
       case 1:printf("%lf",y=x*2+3);break;
       case 2:
       case 3:printf("%lf",y=-0.5*x+10);break;
       default:printf("error");
   }
}
