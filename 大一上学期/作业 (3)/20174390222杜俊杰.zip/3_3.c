#include"stdio.h"
main()
{
    int ma,a,b,t;
    float r;
    scanf("%d",&ma);
    if (ma>=0)
     { t=(int)(ma/1000);
       switch(t)
       {
       case 0:r=0;printf("%d%d",a=ma*0,b=ma*(1-r));break;
       case 1:r=0.05;printf("%d%d",a=ma*0.05,b=ma*(1-r));break;
       case 2:
       case 3:r=0.08;printf("%d%d",a=ma*0.08,b=ma*(1-r));break;
       default:r=0.1;printf("%d%d",a=ma*0.1,b=ma*(1-r));
       }
     }
    else printf("error");
}



