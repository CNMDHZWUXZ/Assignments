#include"stdio.h"
main()
{   float a,b;
    float y;
    scanf("%f",&a);
    b=a;
    switch(a>0)
    {
        case 0:y=0;break;
        case 1: switch((int)b/10)
                {
                  case 0:y=b;break;
                  case 1:y=b+3;break;
                  case 2:
                  case 3:y=-0.5*b+10;break;
                  default:y=2*b-5;break;
                }

    }

    printf("x=%f,y=%f",a,y);
}
