#include"stdio.h"
main()
{
    float ma,tr,ma_tr;
    scanf("%f",&ma);
    switch(ma>=1000)
    {
        case 0:tr=0;break;
        case 1: switch((int)ma/1000)
                {

                   case 1:tr=0.05;break;
                   case 2:tr=0.08;break;
                   case 3:tr=0.08;break;
                   default:tr=0.1;break;
                }
    }
    printf("����Ϊ=%f,˰��Ϊ=%f,Ӧ��˰��=%f,ʵ�ý���=%f\n",ma,tr,ma*tr,ma*(1-tr));
}
