#include"stdio.h"
main()
{
    int a;
    scanf("%d",&a);
    if(a%3==0&&a%4==0&&a%5==0)
       printf("YES");
    else
       printf("No");

}
