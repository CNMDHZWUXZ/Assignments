#include <stdio.h>
main()
{
 int a,b,c,d,e,f,g,h,i,j;
 scanf("%d %d %d %d",&a,&b,&c,&d);
 if(a<b)
 {e=a;a=b;b=e;}
 if(a<c)
 {f=a;a=c;c=f;}
 if(a<d)
 {g=a;a=d;d=g;}
 if(b<c)
 {h=b;b=c;c=h;}
 if(b<d)
 {i=b;b=d;d=i;}
 if(c<d)
 {j=c;c=d;d=j;}
 printf("%d %d %d %d",a,b,c,d);
}
