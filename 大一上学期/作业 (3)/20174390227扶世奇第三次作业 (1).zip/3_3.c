#include <stdio.h>
main()
{
	int m;
	float ma,a,x,y;
	scanf("%f",&ma);
	switch((int)ma/1000)
	{
	case 0:a=0.0;
		x=ma*a;
		y=ma-x;
		printf("%f,%f,%f",a,x,y);break;
    case 1:a=0.05;
		x=ma*a;
		y=ma-x;
	    printf("%f,%f,%f",a,x,y);break;
	case 2:a=0.08;
		x=ma*a;
		y=ma-x;
	    printf("%f,%f,%f",a,x,y);break;
	default:a=0.10;
		x=ma*a;
		y=ma-x;
		printf("%f,%f,%f,",a,x,y);
	}
}
