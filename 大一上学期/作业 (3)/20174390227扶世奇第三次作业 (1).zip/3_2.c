#include <stdio.h>
main()
{
  int yy,mm,day;
  printf("input year and month:");
  scanf("%d%d",&yy,&mm);
  switch(mm)
  {case 1:case 3:case 5:case 7:case 8:case 10:case 12:days=31;
break;
case 4:case 6:case 9:case 11:days=30;
break;
case 2:
    if(yy%4==0&&yy%100!=0||yy%400==0)
        printf(yes);
else  days=28;
   break;
   default:printf("input error");break;

  }
  printf("The days of%d%d is %d\n",yy,mm,days);
}
