#include"stdio.h"
main()
{
	int x;
	double ma,r,x,y;
	scanf("%lf",&ma);
	z=(ma/1000);
	switch(z)
	{
	    case 0:r=0.00;
	    x=ma*r;
		y=ma-x;
		printf("%f%f%f",r,x,y);break;
		case 1:r=0.05;
		x=ma*r;
		y=ma-x;
	    printf("%f%f%f",r,x,y);break;
	    case 2:r=0.08;
		x=ma*r;
		y=ma-x;
	    printf("%f%f%f",r,x,y);break;
	    case 4:r=0.10;
		x=ma*r;
		y=ma-x;
		printf("%f%f%f",r,x,y);	break;
	}
}
