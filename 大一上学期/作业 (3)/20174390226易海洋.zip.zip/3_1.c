#include"stdio.h"
main()
{
	int c;
	double x,y;
	scanf("%lf",&x);
	c=(int)(x/10);
	switch(c)
	{  case 0:
		   printf("%lf",y=x);break;
	   case 1:
		   printf("%lf",y=x*2+3);break;
	   case 2:
		   printf("%lf",y=-0.5*x+10);break;
	   case 3:
		   printf("%lf",y=-0.5*x+10);break;
	   default:printf("input error\n");
	}
}
