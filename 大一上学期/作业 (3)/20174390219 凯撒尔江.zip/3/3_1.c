#include<stdio.h>
main()
{
	float a,b;
	scanf("%f",&a);
	switch((int)a/10)
	{     case 0:printf("y=a",b);break;
	case 1:printf("y=a*2+3",b);break;
	case 2: case 3:printf("b=-0.5*a+10",b);
	}
	printf("b=%f",b);
}
