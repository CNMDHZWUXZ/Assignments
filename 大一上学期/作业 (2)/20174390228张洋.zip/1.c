#include<stdio.h>
main()
{
    char c;
    scanf("%c",&c);
    if(c>='a'&&c<='z'||c>='A'&&c<='Z')
        if(c>='a'&&c<='z')
        printf("\n%c",c-32);
        else
            printf("\n%c",c+32);
        else
            printf("%c\n����Ӣ����ĸ",c);
}
