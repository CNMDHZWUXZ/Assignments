#include<stdio.h>
main()
{
    int count=0,x=1,f=1;
    while(x<=1000)
    {
        f*=x;
        x++;
        if(f>1000)
        {
            for(;f>10&&f%10==0;)
           {
              count+=1;
              f/=10;
           }
            f=f%1000;
        }

    }
    printf("count=%d\n",count);
}
