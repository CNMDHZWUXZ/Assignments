#include<stdio.h>
main()
{
    int x,y=0,w=0/*������*/,m/*��ĸ��*/,c/*������*/;
    for(;w<20;w++)
    {
        for(m=0;m<30;m++)
        {
            for(c=0;c<99;c+=3)
            {
                if(5*w+3*m+c/3==100&&w+m+c==100)
                  printf("w=%d m=%d c=%d\n",w,m,c);

            }
        }
    }
}
