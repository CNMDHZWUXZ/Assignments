#include<stdio.h>
main()
{
    int x=0;
    while(x%5!=1||x%6!=5||x%7!=4||x%11!=10)
        x+=1;
    printf("x=%d",x);
}
