#include<stdio.h>
main()
{
    int x=1,y,n;
    while(x<10)
    {
        for(y=1;x<10&&y<=x;)
            {
              n=x*y;
              printf("%d*%d=%d\t",y,x,n);
              y++;
            }
        if(y=x)
            printf("\n");
        x++;
    }
}
