#include<stdio.h>
main()
{
    int x=0;
    while(x%2!=1||x%3!=2||x%5!=4||x%6!=5||x%7!=0)
        x++;
    printf("x=%d",x);
}
