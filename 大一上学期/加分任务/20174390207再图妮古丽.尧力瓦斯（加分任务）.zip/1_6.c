#include<stdio.h>
main()
{
    int x,y,i;
    for(x=5;x>=1;x--)
    {
        for(i=5-x;i>=1;i--)
        {
            printf(" ");
        }
        for(y=x;y>=1;y--)
        {
            printf("* ");
        }
        printf("\n");
    }
    for(x=2;x<=5;x++)
    {
        for(i=5-x;i>=1;i--)
        {
            printf(" ");
        }
        for(y=x;y>=1;y--)
        {
            printf("* ");
        }
        printf("\n");
    }
}
