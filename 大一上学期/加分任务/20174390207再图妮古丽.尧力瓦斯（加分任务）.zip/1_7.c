#include<stdio.h>
main()
{
    int x,y,i;
    for(x=1;x<=5;x++)
    {
        for(i=5-x;i>=1;i--)
            printf(" ");
        for(y=1;y<x;y++)
            printf("%d",y);
        for(y=x;y>=1;y--)
            printf("%d",y);
        printf("\n");
    }
    for(x=4;x>=1;x--)
    {
        for(i=5-x;i>=1;i--)
            printf(" ");
        for(y=1;y<x;y++)
            printf("%d",y);
        for(y=x;y>=1;y--)
            printf("%d",y);
        printf("\n");
    }
}
