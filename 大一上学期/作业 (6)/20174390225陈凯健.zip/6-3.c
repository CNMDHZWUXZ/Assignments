#include<stdio.h>
int ride(int n)
{
    int x,y;
    for(x=1;x<n;x++)
    {
        for(y=1;y<n;y++)
            if(x*x+y*y==n*n&&x+y>n&&x+n>y&&y+n>x)
            return 1;
    }
    return 0;
}
main()
{
    int n, count=0;
    for(n=1;n<1000;n++)
    {
        if(ride(n))
        {
            printf("%  d",n);
            count++;
        }
    }
    printf("count=%d",count);
}
