#include<stdio.h>
int vim(int x,int y)
{
    int i,sun=1,m=1;
    for(i=1;i<x;i++)
        sun=sun*y;
        return sun;
}
int op(int x)
{
    int i,m;
    for(i=1;i<x;i++)
        m=m*i;
    return m;
}
main()
{
    int i,n,x,count=1;
    scanf("%d%d",&n,&x);
    for(i=1;i<n;i++)
    {
        count=count+vim(i,x)/op(i);
    }
    printf("%d",count);
}
