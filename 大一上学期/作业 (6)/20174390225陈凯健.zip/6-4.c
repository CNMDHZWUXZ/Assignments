#include<stdio.h>
int yue(int x,int y)
{ int t;
  if(x<y)
  {
      t=x;x=y;y=t;
  }
  while((t=x%y)!=0)
  {
      x=y;y=t;}
      return y;

}
main()
{
    int x,y,r;
    scanf("%d%d",&x,&y);
    r=yue(x,y);
    printf("���Լ��%d",r);
}
