#include<stdio.h>
int add(int a,int b)
{
    scanf("%d%d",&a,&b);
    int n=a;
    if (n>b)
        n=b;
    for(int i=a;i>=1;i--)
{
       if (a%i==0&&b%i==0)
       {
              printf("���Լ����%d\n",i);
              break;
       }
	   return 0;
}
}
main()
{
    printf("������������");
    int a,b;
    scanf("%d%d",&a,&b);
    int n=a;
    if (n>b)
       n=b;
       for(int i=n;i>=1;i--)
{
       if (a%i==0&&b%i==0)
       {
              printf("���Լ����%d\n",i);
              break;
       }
}
}
