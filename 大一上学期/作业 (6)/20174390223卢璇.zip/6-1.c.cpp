#include <stdio.h>
int sum(int a,int b)
{
  int n;
  n=a+b;
  return n;
}
main()
{
    int x,y;
    scanf("%d %d",&x,&y);
    printf("�������ĺͣ�%8d\n",sum(x,y));
}
