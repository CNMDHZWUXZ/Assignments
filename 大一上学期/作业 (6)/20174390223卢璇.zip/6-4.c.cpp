#include<stdio.h>
int fun(int m,int n)
{
    int i,j,k,t=0,x;
    for(i=m;i<=n;i++)
    {
        x=0;
        for(j=1;j<i;j++)
            for(k=j;k<i;k++)
            if(i*i==j*j+k*k)
        {
        x=1;
            printf("%d\t",i);
        }
        if(x==1)
            t++;
    }
    return t;
}
main()
{
    int k;
    k=fun(0,1000);
    printf("����=%d\n");

}
