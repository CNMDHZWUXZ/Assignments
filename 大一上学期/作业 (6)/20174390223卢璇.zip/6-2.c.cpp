#include<stdio.h>
int fun(int a)
{
    int b;
    for(b=2;b<a;b++)
        if(a%b==0)
        return 0;
    if(b==a)
        return 1;
    return 0;
}
main()
{
    int a,count=0;
    for (a=1000;a<=10000;a++)
    {
        if(fun(a))
        {
            printf("%d\t",a);
            count++;
            if(count%6==0)
                printf("\n");
        }

    }
    printf("��������%d",count);
}
