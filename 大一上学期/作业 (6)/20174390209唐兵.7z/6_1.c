#include<stdio.h>
int add(int m,int n)
{
	return m+n;
}
main()
{
	int a,b;
	printf("wait an input:");
		scanf("%d %d",&a,&b);
		add(a,b);
		printf("a+b=%d\n",a+b);
}
