#include<stdio.h>
int prime(int m,int n)
{
	int i,j;
	if(n>=m)
	{
		i=m;
		m=n;
		n=i;
	}
	for(i=n;i>=1;i--)
	{
		if(m%i==0&&n%i==0)
		{
			return i;
		    break;
		}
	}
}
main()
{
	int a,b,c;
	printf("input:");
	scanf("%d %d",&a,&b);
	c=prime(a,b);
	printf("%d\n",c);
}
