#include<stdio.h>
int prime(int n)
{
	int i;
	for(i=2;i<n;i++)
		if(n%i==0)
			break;
	if(i==n)
		return 1;
	return 0;
}
main()
{
	int n=1000,count=0;
	for(;n<=10000;n++)
	{
		if(prime(n))
		{
		   printf("%d\t",n);
		   count++;
		}
		if(count%6==0)
            printf("\n");
	}
	printf("count=%d\n",count);

}
