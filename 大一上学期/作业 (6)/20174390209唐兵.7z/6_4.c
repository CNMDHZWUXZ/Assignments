#include<stdio.h>
int prime(int n)
{
	int i,j=1;
	while(j<n)
	{
		for(i=1;i<n;i++)
		{
			if(n*n==i*i+j*j)
				return 1;
		}
		j++;
	}
	return 0;
}
main()
{
	int x=1,count=0;
	for(;x<=1000;x++)
	{
		if(prime(x))
		{
			printf("%-8d",x);
				count++;
		}
	}
	printf("count=%d\n",count);
}
