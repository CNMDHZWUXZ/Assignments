#include<stdio.h>
int prime(int n)
{
	int i;
	for(i=2;i<=n;i++)
	{
		if(n%i!=0)
			continue;
		else if(n==i)
			return 1;
		else return 0;
		
	}

}
main()
{
	int n,count=0;
	for(n=1000;n<=10000;n++)
	{
		if(prime(n))
		{
			printf("%d\t",n);
			count++;
			if(count%6==0)
				printf("\n");
		}
	}
	printf("\ncount=%d\n",count);
}