#include<stdio.h>
#include<math.h>
int f(int n)
{
	int s;
	if(n==0)
		return 1;
	for(s=1;n>0;n--)
		s*=n;
	return s;
}
main()
{
	int n,x;
	float s;
	printf("����������n��x:");
	scanf("%d%d",&n,&x);
	for(s=0;n>=0;n--)
		s+=(float)pow(x,n)/f(n);
	printf("s=%f",s);
}
