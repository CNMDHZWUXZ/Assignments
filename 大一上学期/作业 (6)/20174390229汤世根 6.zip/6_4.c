#include<stdio.h>
int f(int n)
{
	int a,b;
	for(a=1;a<n;a++)
	{
		for(b=1;b<=a;b++)
		{
			if(a*a+b*b==n*n)
				return 1;
		}
	}
	return 0;
}
main()
{
	int n,count=0;
	for(n=1;n<=1000;n++)
	{
		if(f(n))
		{
			printf("%d\t",n);
			count++;
			if(count%6==0)
				printf("\n");
		}
	}
	printf("\ncount=%d\n",count);
}