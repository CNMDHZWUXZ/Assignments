#include <stdio.h>
int main()
{
int i,f=0,j,m=0;
for(i=1000;i<=10000;i++)
{
for(j=2;j<i;j++)
if(i%j==0) break;
if(i==j)
{
printf("%10d ",i);
f++;
m++;
}
if(f==6)
{
printf("\n");
f=0;
}
}
printf("����%d������\n",m);
getchar();
return 0;
}