#include <stdio.h>
int main()
{
int i,j=0,a,b,c;
for(a=0;a<=1000;a++)
for(b=0;b<=1000;b++)
for(c=0;c<=1000;c++)
for(i=0;i<=1000;i++)
if (j==(a*a+b*b==c*c))
i==j;
    printf("����:%d\n",i);
}