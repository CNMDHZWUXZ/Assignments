#include<stdio.h>
#include<math.h>
int factorial(int a)
{
int f=1;
while(a>=1)
f=f*a--;
return f;
}
int prime(int x,int a)
{
int s;
s=pow(x,a);
return s;
}
main()
{
double s=0;
int x,a;
printf("wait an input:");
scanf("%d %d",&x,&a);
for(;a>=0;a--)
s+=(double)prime(x,a)/(double)factorial(a);
printf("s=%f\n",s);
}