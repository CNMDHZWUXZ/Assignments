#include<stdio.h>
int fanchuanshu(int a)
{
    int i;
    for(;a>0;)
    {
        i=a%10;
        a=a/10;
        printf("%d",i);
    }
}
main()
{
    int a,x;
    printf("������һ������:");
    scanf("%d",&a);
     x=fanchuanshu(a);
}