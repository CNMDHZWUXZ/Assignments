#include<stdio.h>
int gcd(int m,int n)
{
    int r,t;
	if(m>n)
    {
        t=m;
        m=n;
        n=t;
    }
    r=n%m;
    while(r!=0)
         m=r;
    return m;

}
main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("���Լ��Ϊ%d",gcd(a,b));
}
