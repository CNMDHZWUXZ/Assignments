#include<stdio.h>
int f1(int n,int x)
{
    int a=1,i;//��x��n�η�
    for(i=1;i<=n;i++)
    {
        a=a*x;
    }
    return a;
}
int f2(int n)//��n�Ľ׳�
{
    int b=1,i;
    for(i=1;i<=n;i++)
    {
        b=b*i;
    }
    return b;
}
double f3(int x,int n)
{
   return f1(n,x)/f2(n);
}
main()
{
    int i,n,x;
    double sum=1;
    scanf("%d%d",&n,&x);
    for(i=1;i<=n;i++)
    {
        sum+=f3(x,i);
    }
    printf("sum=%d",sum);
}
