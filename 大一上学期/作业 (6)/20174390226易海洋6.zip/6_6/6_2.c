#include<stdio.h>
int prime(int y)
{
	int x;
	for(x=2;x<y;x++)
		if(y%x==0)
			break;
	if(x==y)
		return 1;
	return 0;
}
main()
{
	int y,count=0;
	for(y=1000;y<=10000;y++)
		if(prime(y))
		{
			printf("%d\n",y);
			count++;
			if(count%6==0)
				printf("\n");
		}
		printf("��%d������",count);

}
