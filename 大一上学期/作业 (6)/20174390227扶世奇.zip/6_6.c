#include<stdio.h>
int fun(int n)
{
    do
    {
        printf("%d",n%10);
        n=n/10;
    }
    while(n>0);
}
main()
{
    int n=12345;
    printf("%5d",fun(n));
}
