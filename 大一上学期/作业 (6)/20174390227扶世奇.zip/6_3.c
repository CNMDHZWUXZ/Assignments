#include<stdio.h>
int fun(int a,int b)
{
    int t=a<b?a:b;
    while(a%t||b%t)
        t--;
    return t;
}
main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    printf("���Լ��Ϊ%d",fun(a,b));
}
