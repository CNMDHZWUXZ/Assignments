#include<stdio.h>
double add(double x,double y)
{
    double s;
    s=x+y;
    return s;
}
main()
{
    double x,y,sum;
    scanf("%f%f",&x,&y);
       sum=add(x,y);
    printf("%lf",sum);
}
