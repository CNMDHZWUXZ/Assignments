#include<stdio.h>
int fun(int x)
{
    int a,b;
    for(a=1;a<=x;a++)
        for(b=1;b<=x;b++)
          if(x*x==a*a+b*b)
          return 1;
      return 0;
}
main()
{
    int n,sum=0;
    for(n=1;n<=1000;n++)
    {
        if(fun(n))
        {
            printf("%d ",n);
            sum++;
        }
    }
    printf("�����ĸ���Ϊ%d\n",sum);
}
