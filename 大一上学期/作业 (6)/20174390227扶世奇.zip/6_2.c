#include<stdio.h>
int fun(int x)
{
   int y;
   for(y=2;y<x;y++)
    if(x%y==0)
      return 0;
   if(y==x)
      return 1;
   else
    return 0;
}
main()
{
    int x,sum=0;
    for (x=1000;x<=10000;x++)
    {
       if (fun(x))
       {
         printf("%d\t",x);
        sum++;
        if(sum%6==0)
          printf("\n");
        }
    }
    printf("�����ĸ���Ϊ%d\n",sum);
}
