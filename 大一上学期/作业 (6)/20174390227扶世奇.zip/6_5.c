#include<stdio.h>
int fun1(int n)
{
    int m=1;
    for(;n>=2;n--)
        m=m*n;
    return m;
}
int fun2(int x,int y)
{
    for(;y>=2;y--)
        x=x*x;
    return x;
}
main()
{
    float s=1;
    int x,n,i;
    scanf("%d%d",&x,&n);
    for(i=1;i<=n;i++)
        s=s+(float)fun2(x,n)/((float)fun1(n));
    printf("%f",s);
}
