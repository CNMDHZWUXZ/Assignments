#include<stdio.h>
int jiecheng(int n)
{
	int m,s=1;
	for(m=1;m<=n;m++)
		s=s*m;
	   return s;
}
int cifang(int n,int x)
{
	int i,s=1;
	for(i=1;i<=n;i++)
		s*=x;
	   return s;
}

main()
{
	int n,x,i;
	float s=1;
	printf("������n��x\n");
	scanf("%d%d",&n,&x);
	for(i=1;i<=n;i++)
	s=s+(float)cifang(n,x)/(float)jiecheng(n);
	printf("sum=%f\n",s);

}
