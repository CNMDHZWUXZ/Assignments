#include<stdio.h>
int prime(int b)
{
	int i,a;
	for(i=1;i<b;i++)
	{
		for(a=1;a<b;a++)
	if(i*i+a*a==b*b)
		return 1;
	}
	return 0;
}
main()
{
	int b,count=0;
	      for(b=5;b<=1000;b++)
		if(prime(b))
		{
			printf("%d\n",b);
		    count++;
		}
		printf("����%d������\n",count);


}
