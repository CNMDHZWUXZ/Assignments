#include<stdio.h>
int fun(int y)
{
    int i,j;
    for(i=1;i<y;i++)
        for(j=1;j<i;j++)
          if(y*y>=i*i+j*j)
             if(y*y==i*i+j*j)
                  return y;
    return 0;
}
main()
{
    int y,count=0;
    for(y=1;y<=1000;y++)
        if(fun(y))
    {
        printf("%d  ",y);
count++;
    }
    printf("%d\n",count);
}
