#include<stdio.h>
main()
{  int a,b;
    scanf("%d",&a);
     b=fun(a);
     printf("%d\n",fun(a));
}
int fun(int n)
{
    int y=0;
    while(n)
    {
        y*=10;
        y+=n%10;
        n/=10;
    }
    return y;
}
