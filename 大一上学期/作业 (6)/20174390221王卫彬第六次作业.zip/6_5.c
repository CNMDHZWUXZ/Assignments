#include<stdio.h>
main()
{
    float n,x,sum=1;
     scanf("%f%f",&x,&n);
for(n;n>0;n--)
     sum+=fun(x,n);
     printf("%5f",sum);
}
float fun(float x,float n)
{
    float i,c,k=1,s=1;
     for(i=n;i>0;i--)
    {
        x=k*x;
       s=s*i;
    }
    c=x/s;
    return c;
}
