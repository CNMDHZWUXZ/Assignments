#include<stdio.h>
  int fun(int i,int n)
  {   int a=0;
      scanf("%d",&i);
      for(n=2;n<i;n++)
        if(i%n==0)
            a++;
           if(a==0)
                printf("%d",i);
       return 0;
   }
  main()
  {
     int i,n,count=0,a;
     for(i=1000;i<=10000;i++)
    {
         int fun(i,n);
    if(i%j==0)
    {
    count++;
     a++;
     if(a%6==0)
    printf(\n);
    }
    printf("%d\n",count);
    }
   }
