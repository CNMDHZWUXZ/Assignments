#include <stdio.h>
int max(int a,int b)
{
    int t;
    if(b>a)
    {
        t=a;
        a=b;
        b=t;
    }
    while(a%b!=0)
    {
        b=a%b;
        a=b;
     }
     return b;
}
void main()
{
int a,b;
scanf("%d%d",&a,&b);
printf("最大公约数为:%d\n",max(a,b));
}
